//
//  fpUsingMdCell.m
//  mckinsey
//
//  Created by Mac on 10/10/16.
//  Copyright © 2016 Hardcastle. All rights reserved.
//

#import "fpUsingMdCell.h"

@implementation fpUsingMdCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
