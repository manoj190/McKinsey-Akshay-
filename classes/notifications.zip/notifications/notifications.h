//
//  notifications.h
//  mckinsey
//
//  Created by Mac on 14/12/16.
//  Copyright © 2016 Hardcastle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface notifications : UIViewController<UITableViewDelegate,UITableViewDataSource>

@end
